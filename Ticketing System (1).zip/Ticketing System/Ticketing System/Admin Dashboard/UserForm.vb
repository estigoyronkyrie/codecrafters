﻿Public Class UserForm
    Private Sub btnLogout_Click(sender As System.Object, e As System.EventArgs)
        Utilities.CurrentUser = ""
        Utilities.CurrentUserType = 0

        Me.Hide()
        LoginForm.txtUsername.Text = ""
        LoginForm.txtPassword.Text = ""
    End Sub

    Private Sub UserForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
