﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserScheduleAndSeat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UserScheduleAndSeat))
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.Seat01 = New System.Windows.Forms.PictureBox()
        Me.lblChooseSeat = New System.Windows.Forms.Label()
        Me.Seat05 = New System.Windows.Forms.PictureBox()
        Me.Seat09 = New System.Windows.Forms.PictureBox()
        Me.Seat13 = New System.Windows.Forms.PictureBox()
        Me.Seat17 = New System.Windows.Forms.PictureBox()
        Me.Seat21 = New System.Windows.Forms.PictureBox()
        Me.Seat25 = New System.Windows.Forms.PictureBox()
        Me.Seat29 = New System.Windows.Forms.PictureBox()
        Me.Seat33 = New System.Windows.Forms.PictureBox()
        Me.Seat37 = New System.Windows.Forms.PictureBox()
        Me.Seat38 = New System.Windows.Forms.PictureBox()
        Me.Seat34 = New System.Windows.Forms.PictureBox()
        Me.Seat30 = New System.Windows.Forms.PictureBox()
        Me.Seat26 = New System.Windows.Forms.PictureBox()
        Me.Seat22 = New System.Windows.Forms.PictureBox()
        Me.Seat18 = New System.Windows.Forms.PictureBox()
        Me.Seat14 = New System.Windows.Forms.PictureBox()
        Me.Seat10 = New System.Windows.Forms.PictureBox()
        Me.Seat06 = New System.Windows.Forms.PictureBox()
        Me.Seat02 = New System.Windows.Forms.PictureBox()
        Me.Seat40 = New System.Windows.Forms.PictureBox()
        Me.Seat36 = New System.Windows.Forms.PictureBox()
        Me.Seat32 = New System.Windows.Forms.PictureBox()
        Me.Seat28 = New System.Windows.Forms.PictureBox()
        Me.Seat24 = New System.Windows.Forms.PictureBox()
        Me.Seat20 = New System.Windows.Forms.PictureBox()
        Me.Seat16 = New System.Windows.Forms.PictureBox()
        Me.Seat12 = New System.Windows.Forms.PictureBox()
        Me.Seat08 = New System.Windows.Forms.PictureBox()
        Me.Seat04 = New System.Windows.Forms.PictureBox()
        Me.Seat39 = New System.Windows.Forms.PictureBox()
        Me.Seat35 = New System.Windows.Forms.PictureBox()
        Me.Seat31 = New System.Windows.Forms.PictureBox()
        Me.Seat27 = New System.Windows.Forms.PictureBox()
        Me.Seat23 = New System.Windows.Forms.PictureBox()
        Me.Seat19 = New System.Windows.Forms.PictureBox()
        Me.Seat15 = New System.Windows.Forms.PictureBox()
        Me.Seat11 = New System.Windows.Forms.PictureBox()
        Me.Seat07 = New System.Windows.Forms.PictureBox()
        Me.Seat03 = New System.Windows.Forms.PictureBox()
        Me.lbl01 = New System.Windows.Forms.Label()
        Me.lbl03 = New System.Windows.Forms.Label()
        Me.lbl04 = New System.Windows.Forms.Label()
        Me.lbl05 = New System.Windows.Forms.Label()
        Me.lbl07 = New System.Windows.Forms.Label()
        Me.lbl08 = New System.Windows.Forms.Label()
        Me.lbl09 = New System.Windows.Forms.Label()
        Me.lbl20 = New System.Windows.Forms.Label()
        Me.lbl19 = New System.Windows.Forms.Label()
        Me.lbl17 = New System.Windows.Forms.Label()
        Me.lbl16 = New System.Windows.Forms.Label()
        Me.lbl15 = New System.Windows.Forms.Label()
        Me.lbl13 = New System.Windows.Forms.Label()
        Me.lbl12 = New System.Windows.Forms.Label()
        Me.lbl11 = New System.Windows.Forms.Label()
        Me.lbl25 = New System.Windows.Forms.Label()
        Me.lbl24 = New System.Windows.Forms.Label()
        Me.lbl23 = New System.Windows.Forms.Label()
        Me.lbl21 = New System.Windows.Forms.Label()
        Me.lbl28 = New System.Windows.Forms.Label()
        Me.lbl27 = New System.Windows.Forms.Label()
        Me.lbl32 = New System.Windows.Forms.Label()
        Me.lbl31 = New System.Windows.Forms.Label()
        Me.lbl29 = New System.Windows.Forms.Label()
        Me.lbl36 = New System.Windows.Forms.Label()
        Me.lbl35 = New System.Windows.Forms.Label()
        Me.lbl33 = New System.Windows.Forms.Label()
        Me.lbl40 = New System.Windows.Forms.Label()
        Me.lbl39 = New System.Windows.Forms.Label()
        Me.lbl37 = New System.Windows.Forms.Label()
        Me.lbl45 = New System.Windows.Forms.Label()
        Me.lbl44 = New System.Windows.Forms.Label()
        Me.lbl41 = New System.Windows.Forms.Label()
        Me.Seat45 = New System.Windows.Forms.PictureBox()
        Me.Seat44 = New System.Windows.Forms.PictureBox()
        Me.Seat43 = New System.Windows.Forms.PictureBox()
        Me.Seat42 = New System.Windows.Forms.PictureBox()
        Me.Seat41 = New System.Windows.Forms.PictureBox()
        Me.lbl43 = New System.Windows.Forms.Label()
        Me.lblAvailable = New System.Windows.Forms.Label()
        Me.lblOccupied = New System.Windows.Forms.Label()
        Me.picboxAvailable = New System.Windows.Forms.PictureBox()
        Me.picboxOccupied = New System.Windows.Forms.PictureBox()
        Me.lblChooseDestination = New System.Windows.Forms.Label()
        Me.comboxTerminalDeparture = New System.Windows.Forms.ComboBox()
        Me.comboxTerminalDestination = New System.Windows.Forms.ComboBox()
        Me.datepickerDeparture = New System.Windows.Forms.DateTimePicker()
        Me.pickPassenger = New System.Windows.Forms.NumericUpDown()
        Me.lblPassenger = New System.Windows.Forms.Label()
        Me.comboxBusClassType = New System.Windows.Forms.ComboBox()
        Me.lblBusClassType = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.comboxTimeDeparture = New System.Windows.Forms.ComboBox()
        Me.lblTerminalDeparture = New System.Windows.Forms.Label()
        Me.lblDateDeparture = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblTerminalDestination = New System.Windows.Forms.Label()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.lbl38 = New System.Windows.Forms.Label()
        Me.lbl42 = New System.Windows.Forms.Label()
        Me.lbl18 = New System.Windows.Forms.Label()
        Me.lbl22 = New System.Windows.Forms.Label()
        Me.lbl34 = New System.Windows.Forms.Label()
        Me.lbl14 = New System.Windows.Forms.Label()
        Me.lbl26 = New System.Windows.Forms.Label()
        Me.lbl30 = New System.Windows.Forms.Label()
        Me.lbl02 = New System.Windows.Forms.Label()
        Me.lbl06 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        CType(Me.Seat01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat05, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat09, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat06, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat08, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat04, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat07, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat03, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seat41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picboxAvailable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picboxOccupied, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pickPassenger, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.ForeColor = System.Drawing.Color.Black
        Me.btnSubmit.Location = New System.Drawing.Point(702, 556)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(147, 36)
        Me.btnSubmit.TabIndex = 4
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'Seat01
        '
        Me.Seat01.Image = CType(resources.GetObject("Seat01.Image"), System.Drawing.Image)
        Me.Seat01.Location = New System.Drawing.Point(214, 25)
        Me.Seat01.Name = "Seat01"
        Me.Seat01.Size = New System.Drawing.Size(49, 50)
        Me.Seat01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat01.TabIndex = 10
        Me.Seat01.TabStop = False
        '
        'lblChooseSeat
        '
        Me.lblChooseSeat.AutoSize = True
        Me.lblChooseSeat.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChooseSeat.Location = New System.Drawing.Point(30, 255)
        Me.lblChooseSeat.Name = "lblChooseSeat"
        Me.lblChooseSeat.Size = New System.Drawing.Size(113, 24)
        Me.lblChooseSeat.TabIndex = 11
        Me.lblChooseSeat.Text = "Choose Seat:"
        '
        'Seat05
        '
        Me.Seat05.Image = CType(resources.GetObject("Seat05.Image"), System.Drawing.Image)
        Me.Seat05.Location = New System.Drawing.Point(214, 92)
        Me.Seat05.Name = "Seat05"
        Me.Seat05.Size = New System.Drawing.Size(49, 50)
        Me.Seat05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat05.TabIndex = 12
        Me.Seat05.TabStop = False
        '
        'Seat09
        '
        Me.Seat09.ErrorImage = CType(resources.GetObject("Seat09.ErrorImage"), System.Drawing.Image)
        Me.Seat09.Image = CType(resources.GetObject("Seat09.Image"), System.Drawing.Image)
        Me.Seat09.Location = New System.Drawing.Point(214, 158)
        Me.Seat09.Name = "Seat09"
        Me.Seat09.Size = New System.Drawing.Size(49, 50)
        Me.Seat09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat09.TabIndex = 13
        Me.Seat09.TabStop = False
        '
        'Seat13
        '
        Me.Seat13.Image = CType(resources.GetObject("Seat13.Image"), System.Drawing.Image)
        Me.Seat13.Location = New System.Drawing.Point(214, 224)
        Me.Seat13.Name = "Seat13"
        Me.Seat13.Size = New System.Drawing.Size(49, 50)
        Me.Seat13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat13.TabIndex = 14
        Me.Seat13.TabStop = False
        '
        'Seat17
        '
        Me.Seat17.Image = CType(resources.GetObject("Seat17.Image"), System.Drawing.Image)
        Me.Seat17.Location = New System.Drawing.Point(214, 290)
        Me.Seat17.Name = "Seat17"
        Me.Seat17.Size = New System.Drawing.Size(49, 50)
        Me.Seat17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat17.TabIndex = 15
        Me.Seat17.TabStop = False
        '
        'Seat21
        '
        Me.Seat21.Image = CType(resources.GetObject("Seat21.Image"), System.Drawing.Image)
        Me.Seat21.Location = New System.Drawing.Point(214, 356)
        Me.Seat21.Name = "Seat21"
        Me.Seat21.Size = New System.Drawing.Size(49, 50)
        Me.Seat21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat21.TabIndex = 16
        Me.Seat21.TabStop = False
        '
        'Seat25
        '
        Me.Seat25.Image = CType(resources.GetObject("Seat25.Image"), System.Drawing.Image)
        Me.Seat25.Location = New System.Drawing.Point(214, 422)
        Me.Seat25.Name = "Seat25"
        Me.Seat25.Size = New System.Drawing.Size(49, 50)
        Me.Seat25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat25.TabIndex = 17
        Me.Seat25.TabStop = False
        '
        'Seat29
        '
        Me.Seat29.Image = CType(resources.GetObject("Seat29.Image"), System.Drawing.Image)
        Me.Seat29.Location = New System.Drawing.Point(214, 488)
        Me.Seat29.Name = "Seat29"
        Me.Seat29.Size = New System.Drawing.Size(49, 50)
        Me.Seat29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat29.TabIndex = 18
        Me.Seat29.TabStop = False
        '
        'Seat33
        '
        Me.Seat33.Image = CType(resources.GetObject("Seat33.Image"), System.Drawing.Image)
        Me.Seat33.Location = New System.Drawing.Point(214, 554)
        Me.Seat33.Name = "Seat33"
        Me.Seat33.Size = New System.Drawing.Size(49, 50)
        Me.Seat33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat33.TabIndex = 19
        Me.Seat33.TabStop = False
        '
        'Seat37
        '
        Me.Seat37.Image = CType(resources.GetObject("Seat37.Image"), System.Drawing.Image)
        Me.Seat37.Location = New System.Drawing.Point(214, 620)
        Me.Seat37.Name = "Seat37"
        Me.Seat37.Size = New System.Drawing.Size(49, 50)
        Me.Seat37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat37.TabIndex = 20
        Me.Seat37.TabStop = False
        '
        'Seat38
        '
        Me.Seat38.Image = CType(resources.GetObject("Seat38.Image"), System.Drawing.Image)
        Me.Seat38.Location = New System.Drawing.Point(304, 620)
        Me.Seat38.Name = "Seat38"
        Me.Seat38.Size = New System.Drawing.Size(49, 50)
        Me.Seat38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat38.TabIndex = 30
        Me.Seat38.TabStop = False
        '
        'Seat34
        '
        Me.Seat34.Image = CType(resources.GetObject("Seat34.Image"), System.Drawing.Image)
        Me.Seat34.Location = New System.Drawing.Point(304, 554)
        Me.Seat34.Name = "Seat34"
        Me.Seat34.Size = New System.Drawing.Size(49, 50)
        Me.Seat34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat34.TabIndex = 29
        Me.Seat34.TabStop = False
        '
        'Seat30
        '
        Me.Seat30.Image = CType(resources.GetObject("Seat30.Image"), System.Drawing.Image)
        Me.Seat30.Location = New System.Drawing.Point(304, 488)
        Me.Seat30.Name = "Seat30"
        Me.Seat30.Size = New System.Drawing.Size(49, 50)
        Me.Seat30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat30.TabIndex = 28
        Me.Seat30.TabStop = False
        '
        'Seat26
        '
        Me.Seat26.Image = CType(resources.GetObject("Seat26.Image"), System.Drawing.Image)
        Me.Seat26.Location = New System.Drawing.Point(304, 422)
        Me.Seat26.Name = "Seat26"
        Me.Seat26.Size = New System.Drawing.Size(49, 50)
        Me.Seat26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat26.TabIndex = 27
        Me.Seat26.TabStop = False
        '
        'Seat22
        '
        Me.Seat22.Image = CType(resources.GetObject("Seat22.Image"), System.Drawing.Image)
        Me.Seat22.Location = New System.Drawing.Point(304, 356)
        Me.Seat22.Name = "Seat22"
        Me.Seat22.Size = New System.Drawing.Size(49, 50)
        Me.Seat22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat22.TabIndex = 26
        Me.Seat22.TabStop = False
        '
        'Seat18
        '
        Me.Seat18.Image = CType(resources.GetObject("Seat18.Image"), System.Drawing.Image)
        Me.Seat18.Location = New System.Drawing.Point(304, 290)
        Me.Seat18.Name = "Seat18"
        Me.Seat18.Size = New System.Drawing.Size(49, 50)
        Me.Seat18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat18.TabIndex = 25
        Me.Seat18.TabStop = False
        '
        'Seat14
        '
        Me.Seat14.Image = CType(resources.GetObject("Seat14.Image"), System.Drawing.Image)
        Me.Seat14.Location = New System.Drawing.Point(304, 224)
        Me.Seat14.Name = "Seat14"
        Me.Seat14.Size = New System.Drawing.Size(49, 50)
        Me.Seat14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat14.TabIndex = 24
        Me.Seat14.TabStop = False
        '
        'Seat10
        '
        Me.Seat10.ErrorImage = CType(resources.GetObject("Seat10.ErrorImage"), System.Drawing.Image)
        Me.Seat10.Image = CType(resources.GetObject("Seat10.Image"), System.Drawing.Image)
        Me.Seat10.Location = New System.Drawing.Point(304, 158)
        Me.Seat10.Name = "Seat10"
        Me.Seat10.Size = New System.Drawing.Size(49, 50)
        Me.Seat10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat10.TabIndex = 23
        Me.Seat10.TabStop = False
        '
        'Seat06
        '
        Me.Seat06.Image = CType(resources.GetObject("Seat06.Image"), System.Drawing.Image)
        Me.Seat06.Location = New System.Drawing.Point(304, 92)
        Me.Seat06.Name = "Seat06"
        Me.Seat06.Size = New System.Drawing.Size(49, 50)
        Me.Seat06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat06.TabIndex = 22
        Me.Seat06.TabStop = False
        '
        'Seat02
        '
        Me.Seat02.Image = CType(resources.GetObject("Seat02.Image"), System.Drawing.Image)
        Me.Seat02.Location = New System.Drawing.Point(304, 25)
        Me.Seat02.Name = "Seat02"
        Me.Seat02.Size = New System.Drawing.Size(49, 50)
        Me.Seat02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat02.TabIndex = 21
        Me.Seat02.TabStop = False
        '
        'Seat40
        '
        Me.Seat40.Image = CType(resources.GetObject("Seat40.Image"), System.Drawing.Image)
        Me.Seat40.Location = New System.Drawing.Point(503, 620)
        Me.Seat40.Name = "Seat40"
        Me.Seat40.Size = New System.Drawing.Size(49, 50)
        Me.Seat40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat40.TabIndex = 51
        Me.Seat40.TabStop = False
        '
        'Seat36
        '
        Me.Seat36.Image = CType(resources.GetObject("Seat36.Image"), System.Drawing.Image)
        Me.Seat36.Location = New System.Drawing.Point(503, 554)
        Me.Seat36.Name = "Seat36"
        Me.Seat36.Size = New System.Drawing.Size(49, 50)
        Me.Seat36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat36.TabIndex = 50
        Me.Seat36.TabStop = False
        '
        'Seat32
        '
        Me.Seat32.Image = CType(resources.GetObject("Seat32.Image"), System.Drawing.Image)
        Me.Seat32.Location = New System.Drawing.Point(503, 488)
        Me.Seat32.Name = "Seat32"
        Me.Seat32.Size = New System.Drawing.Size(49, 50)
        Me.Seat32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat32.TabIndex = 49
        Me.Seat32.TabStop = False
        '
        'Seat28
        '
        Me.Seat28.Image = CType(resources.GetObject("Seat28.Image"), System.Drawing.Image)
        Me.Seat28.Location = New System.Drawing.Point(503, 422)
        Me.Seat28.Name = "Seat28"
        Me.Seat28.Size = New System.Drawing.Size(49, 50)
        Me.Seat28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat28.TabIndex = 48
        Me.Seat28.TabStop = False
        '
        'Seat24
        '
        Me.Seat24.Image = CType(resources.GetObject("Seat24.Image"), System.Drawing.Image)
        Me.Seat24.Location = New System.Drawing.Point(503, 356)
        Me.Seat24.Name = "Seat24"
        Me.Seat24.Size = New System.Drawing.Size(49, 50)
        Me.Seat24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat24.TabIndex = 47
        Me.Seat24.TabStop = False
        '
        'Seat20
        '
        Me.Seat20.Image = CType(resources.GetObject("Seat20.Image"), System.Drawing.Image)
        Me.Seat20.Location = New System.Drawing.Point(503, 290)
        Me.Seat20.Name = "Seat20"
        Me.Seat20.Size = New System.Drawing.Size(49, 50)
        Me.Seat20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat20.TabIndex = 46
        Me.Seat20.TabStop = False
        '
        'Seat16
        '
        Me.Seat16.Image = CType(resources.GetObject("Seat16.Image"), System.Drawing.Image)
        Me.Seat16.Location = New System.Drawing.Point(503, 224)
        Me.Seat16.Name = "Seat16"
        Me.Seat16.Size = New System.Drawing.Size(49, 50)
        Me.Seat16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat16.TabIndex = 45
        Me.Seat16.TabStop = False
        '
        'Seat12
        '
        Me.Seat12.ErrorImage = CType(resources.GetObject("Seat12.ErrorImage"), System.Drawing.Image)
        Me.Seat12.Image = CType(resources.GetObject("Seat12.Image"), System.Drawing.Image)
        Me.Seat12.Location = New System.Drawing.Point(503, 158)
        Me.Seat12.Name = "Seat12"
        Me.Seat12.Size = New System.Drawing.Size(49, 50)
        Me.Seat12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat12.TabIndex = 44
        Me.Seat12.TabStop = False
        '
        'Seat08
        '
        Me.Seat08.Image = CType(resources.GetObject("Seat08.Image"), System.Drawing.Image)
        Me.Seat08.Location = New System.Drawing.Point(503, 92)
        Me.Seat08.Name = "Seat08"
        Me.Seat08.Size = New System.Drawing.Size(49, 50)
        Me.Seat08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat08.TabIndex = 43
        Me.Seat08.TabStop = False
        '
        'Seat04
        '
        Me.Seat04.Image = CType(resources.GetObject("Seat04.Image"), System.Drawing.Image)
        Me.Seat04.Location = New System.Drawing.Point(503, 25)
        Me.Seat04.Name = "Seat04"
        Me.Seat04.Size = New System.Drawing.Size(49, 50)
        Me.Seat04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat04.TabIndex = 42
        Me.Seat04.TabStop = False
        '
        'Seat39
        '
        Me.Seat39.Image = CType(resources.GetObject("Seat39.Image"), System.Drawing.Image)
        Me.Seat39.Location = New System.Drawing.Point(414, 620)
        Me.Seat39.Name = "Seat39"
        Me.Seat39.Size = New System.Drawing.Size(49, 50)
        Me.Seat39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat39.TabIndex = 41
        Me.Seat39.TabStop = False
        '
        'Seat35
        '
        Me.Seat35.Image = CType(resources.GetObject("Seat35.Image"), System.Drawing.Image)
        Me.Seat35.Location = New System.Drawing.Point(414, 554)
        Me.Seat35.Name = "Seat35"
        Me.Seat35.Size = New System.Drawing.Size(49, 50)
        Me.Seat35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat35.TabIndex = 40
        Me.Seat35.TabStop = False
        '
        'Seat31
        '
        Me.Seat31.Image = CType(resources.GetObject("Seat31.Image"), System.Drawing.Image)
        Me.Seat31.Location = New System.Drawing.Point(414, 488)
        Me.Seat31.Name = "Seat31"
        Me.Seat31.Size = New System.Drawing.Size(49, 50)
        Me.Seat31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat31.TabIndex = 39
        Me.Seat31.TabStop = False
        '
        'Seat27
        '
        Me.Seat27.Image = CType(resources.GetObject("Seat27.Image"), System.Drawing.Image)
        Me.Seat27.Location = New System.Drawing.Point(414, 422)
        Me.Seat27.Name = "Seat27"
        Me.Seat27.Size = New System.Drawing.Size(49, 50)
        Me.Seat27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat27.TabIndex = 38
        Me.Seat27.TabStop = False
        '
        'Seat23
        '
        Me.Seat23.Image = CType(resources.GetObject("Seat23.Image"), System.Drawing.Image)
        Me.Seat23.Location = New System.Drawing.Point(414, 356)
        Me.Seat23.Name = "Seat23"
        Me.Seat23.Size = New System.Drawing.Size(49, 50)
        Me.Seat23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat23.TabIndex = 37
        Me.Seat23.TabStop = False
        '
        'Seat19
        '
        Me.Seat19.Image = CType(resources.GetObject("Seat19.Image"), System.Drawing.Image)
        Me.Seat19.Location = New System.Drawing.Point(414, 290)
        Me.Seat19.Name = "Seat19"
        Me.Seat19.Size = New System.Drawing.Size(49, 50)
        Me.Seat19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat19.TabIndex = 36
        Me.Seat19.TabStop = False
        '
        'Seat15
        '
        Me.Seat15.Image = CType(resources.GetObject("Seat15.Image"), System.Drawing.Image)
        Me.Seat15.Location = New System.Drawing.Point(414, 224)
        Me.Seat15.Name = "Seat15"
        Me.Seat15.Size = New System.Drawing.Size(49, 50)
        Me.Seat15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat15.TabIndex = 35
        Me.Seat15.TabStop = False
        '
        'Seat11
        '
        Me.Seat11.ErrorImage = CType(resources.GetObject("Seat11.ErrorImage"), System.Drawing.Image)
        Me.Seat11.Image = CType(resources.GetObject("Seat11.Image"), System.Drawing.Image)
        Me.Seat11.Location = New System.Drawing.Point(414, 158)
        Me.Seat11.Name = "Seat11"
        Me.Seat11.Size = New System.Drawing.Size(49, 50)
        Me.Seat11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat11.TabIndex = 34
        Me.Seat11.TabStop = False
        '
        'Seat07
        '
        Me.Seat07.Image = CType(resources.GetObject("Seat07.Image"), System.Drawing.Image)
        Me.Seat07.Location = New System.Drawing.Point(414, 92)
        Me.Seat07.Name = "Seat07"
        Me.Seat07.Size = New System.Drawing.Size(49, 50)
        Me.Seat07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat07.TabIndex = 33
        Me.Seat07.TabStop = False
        '
        'Seat03
        '
        Me.Seat03.Image = CType(resources.GetObject("Seat03.Image"), System.Drawing.Image)
        Me.Seat03.Location = New System.Drawing.Point(414, 25)
        Me.Seat03.Name = "Seat03"
        Me.Seat03.Size = New System.Drawing.Size(49, 50)
        Me.Seat03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat03.TabIndex = 32
        Me.Seat03.TabStop = False
        '
        'lbl01
        '
        Me.lbl01.AutoSize = True
        Me.lbl01.BackColor = System.Drawing.Color.Transparent
        Me.lbl01.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl01.ForeColor = System.Drawing.Color.White
        Me.lbl01.Location = New System.Drawing.Point(178, 54)
        Me.lbl01.Name = "lbl01"
        Me.lbl01.Size = New System.Drawing.Size(30, 24)
        Me.lbl01.TabIndex = 52
        Me.lbl01.Text = "01"
        '
        'lbl03
        '
        Me.lbl03.AutoSize = True
        Me.lbl03.BackColor = System.Drawing.Color.Transparent
        Me.lbl03.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl03.ForeColor = System.Drawing.Color.White
        Me.lbl03.Location = New System.Drawing.Point(469, 54)
        Me.lbl03.Name = "lbl03"
        Me.lbl03.Size = New System.Drawing.Size(30, 24)
        Me.lbl03.TabIndex = 54
        Me.lbl03.Text = "03"
        '
        'lbl04
        '
        Me.lbl04.AutoSize = True
        Me.lbl04.BackColor = System.Drawing.Color.Transparent
        Me.lbl04.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl04.ForeColor = System.Drawing.Color.White
        Me.lbl04.Location = New System.Drawing.Point(558, 54)
        Me.lbl04.Name = "lbl04"
        Me.lbl04.Size = New System.Drawing.Size(30, 24)
        Me.lbl04.TabIndex = 55
        Me.lbl04.Text = "04"
        '
        'lbl05
        '
        Me.lbl05.AutoSize = True
        Me.lbl05.BackColor = System.Drawing.Color.Transparent
        Me.lbl05.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl05.ForeColor = System.Drawing.Color.White
        Me.lbl05.Location = New System.Drawing.Point(178, 121)
        Me.lbl05.Name = "lbl05"
        Me.lbl05.Size = New System.Drawing.Size(30, 24)
        Me.lbl05.TabIndex = 56
        Me.lbl05.Text = "05"
        '
        'lbl07
        '
        Me.lbl07.AutoSize = True
        Me.lbl07.BackColor = System.Drawing.Color.Transparent
        Me.lbl07.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl07.ForeColor = System.Drawing.Color.White
        Me.lbl07.Location = New System.Drawing.Point(469, 121)
        Me.lbl07.Name = "lbl07"
        Me.lbl07.Size = New System.Drawing.Size(30, 24)
        Me.lbl07.TabIndex = 58
        Me.lbl07.Text = "07"
        '
        'lbl08
        '
        Me.lbl08.AutoSize = True
        Me.lbl08.BackColor = System.Drawing.Color.Transparent
        Me.lbl08.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl08.ForeColor = System.Drawing.Color.White
        Me.lbl08.Location = New System.Drawing.Point(558, 121)
        Me.lbl08.Name = "lbl08"
        Me.lbl08.Size = New System.Drawing.Size(30, 24)
        Me.lbl08.TabIndex = 59
        Me.lbl08.Text = "08"
        '
        'lbl09
        '
        Me.lbl09.AutoSize = True
        Me.lbl09.BackColor = System.Drawing.Color.Transparent
        Me.lbl09.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl09.ForeColor = System.Drawing.Color.White
        Me.lbl09.Location = New System.Drawing.Point(178, 187)
        Me.lbl09.Name = "lbl09"
        Me.lbl09.Size = New System.Drawing.Size(30, 24)
        Me.lbl09.TabIndex = 60
        Me.lbl09.Text = "09"
        '
        'lbl20
        '
        Me.lbl20.AutoSize = True
        Me.lbl20.BackColor = System.Drawing.Color.Transparent
        Me.lbl20.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl20.ForeColor = System.Drawing.Color.White
        Me.lbl20.Location = New System.Drawing.Point(558, 319)
        Me.lbl20.Name = "lbl20"
        Me.lbl20.Size = New System.Drawing.Size(30, 24)
        Me.lbl20.TabIndex = 71
        Me.lbl20.Text = "20"
        '
        'lbl19
        '
        Me.lbl19.AutoSize = True
        Me.lbl19.BackColor = System.Drawing.Color.Transparent
        Me.lbl19.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl19.ForeColor = System.Drawing.Color.White
        Me.lbl19.Location = New System.Drawing.Point(469, 319)
        Me.lbl19.Name = "lbl19"
        Me.lbl19.Size = New System.Drawing.Size(30, 24)
        Me.lbl19.TabIndex = 70
        Me.lbl19.Text = "19"
        '
        'lbl17
        '
        Me.lbl17.AutoSize = True
        Me.lbl17.BackColor = System.Drawing.Color.Transparent
        Me.lbl17.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl17.ForeColor = System.Drawing.Color.White
        Me.lbl17.Location = New System.Drawing.Point(178, 319)
        Me.lbl17.Name = "lbl17"
        Me.lbl17.Size = New System.Drawing.Size(30, 24)
        Me.lbl17.TabIndex = 68
        Me.lbl17.Text = "17"
        '
        'lbl16
        '
        Me.lbl16.AutoSize = True
        Me.lbl16.BackColor = System.Drawing.Color.Transparent
        Me.lbl16.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl16.ForeColor = System.Drawing.Color.White
        Me.lbl16.Location = New System.Drawing.Point(558, 253)
        Me.lbl16.Name = "lbl16"
        Me.lbl16.Size = New System.Drawing.Size(30, 24)
        Me.lbl16.TabIndex = 67
        Me.lbl16.Text = "16"
        '
        'lbl15
        '
        Me.lbl15.AutoSize = True
        Me.lbl15.BackColor = System.Drawing.Color.Transparent
        Me.lbl15.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl15.ForeColor = System.Drawing.Color.White
        Me.lbl15.Location = New System.Drawing.Point(469, 253)
        Me.lbl15.Name = "lbl15"
        Me.lbl15.Size = New System.Drawing.Size(30, 24)
        Me.lbl15.TabIndex = 66
        Me.lbl15.Text = "15"
        '
        'lbl13
        '
        Me.lbl13.AutoSize = True
        Me.lbl13.BackColor = System.Drawing.Color.Transparent
        Me.lbl13.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl13.ForeColor = System.Drawing.Color.White
        Me.lbl13.Location = New System.Drawing.Point(178, 253)
        Me.lbl13.Name = "lbl13"
        Me.lbl13.Size = New System.Drawing.Size(30, 24)
        Me.lbl13.TabIndex = 64
        Me.lbl13.Text = "13"
        '
        'lbl12
        '
        Me.lbl12.AutoSize = True
        Me.lbl12.BackColor = System.Drawing.Color.Transparent
        Me.lbl12.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl12.ForeColor = System.Drawing.Color.White
        Me.lbl12.Location = New System.Drawing.Point(558, 187)
        Me.lbl12.Name = "lbl12"
        Me.lbl12.Size = New System.Drawing.Size(30, 24)
        Me.lbl12.TabIndex = 63
        Me.lbl12.Text = "12"
        '
        'lbl11
        '
        Me.lbl11.AutoSize = True
        Me.lbl11.BackColor = System.Drawing.Color.Transparent
        Me.lbl11.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl11.ForeColor = System.Drawing.Color.White
        Me.lbl11.Location = New System.Drawing.Point(469, 187)
        Me.lbl11.Name = "lbl11"
        Me.lbl11.Size = New System.Drawing.Size(30, 24)
        Me.lbl11.TabIndex = 62
        Me.lbl11.Text = "11"
        '
        'lbl25
        '
        Me.lbl25.AutoSize = True
        Me.lbl25.BackColor = System.Drawing.Color.Transparent
        Me.lbl25.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl25.ForeColor = System.Drawing.Color.White
        Me.lbl25.Location = New System.Drawing.Point(178, 451)
        Me.lbl25.Name = "lbl25"
        Me.lbl25.Size = New System.Drawing.Size(30, 24)
        Me.lbl25.TabIndex = 76
        Me.lbl25.Text = "25"
        '
        'lbl24
        '
        Me.lbl24.AutoSize = True
        Me.lbl24.BackColor = System.Drawing.Color.Transparent
        Me.lbl24.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl24.ForeColor = System.Drawing.Color.White
        Me.lbl24.Location = New System.Drawing.Point(558, 385)
        Me.lbl24.Name = "lbl24"
        Me.lbl24.Size = New System.Drawing.Size(30, 24)
        Me.lbl24.TabIndex = 75
        Me.lbl24.Text = "24"
        '
        'lbl23
        '
        Me.lbl23.AutoSize = True
        Me.lbl23.BackColor = System.Drawing.Color.Transparent
        Me.lbl23.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl23.ForeColor = System.Drawing.Color.White
        Me.lbl23.Location = New System.Drawing.Point(467, 385)
        Me.lbl23.Name = "lbl23"
        Me.lbl23.Size = New System.Drawing.Size(30, 24)
        Me.lbl23.TabIndex = 74
        Me.lbl23.Text = "23"
        '
        'lbl21
        '
        Me.lbl21.AutoSize = True
        Me.lbl21.BackColor = System.Drawing.Color.Transparent
        Me.lbl21.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl21.ForeColor = System.Drawing.Color.White
        Me.lbl21.Location = New System.Drawing.Point(178, 385)
        Me.lbl21.Name = "lbl21"
        Me.lbl21.Size = New System.Drawing.Size(30, 24)
        Me.lbl21.TabIndex = 72
        Me.lbl21.Text = "21"
        '
        'lbl28
        '
        Me.lbl28.AutoSize = True
        Me.lbl28.BackColor = System.Drawing.Color.Transparent
        Me.lbl28.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl28.ForeColor = System.Drawing.Color.White
        Me.lbl28.Location = New System.Drawing.Point(559, 451)
        Me.lbl28.Name = "lbl28"
        Me.lbl28.Size = New System.Drawing.Size(30, 24)
        Me.lbl28.TabIndex = 79
        Me.lbl28.Text = "28"
        '
        'lbl27
        '
        Me.lbl27.AutoSize = True
        Me.lbl27.BackColor = System.Drawing.Color.Transparent
        Me.lbl27.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl27.ForeColor = System.Drawing.Color.White
        Me.lbl27.Location = New System.Drawing.Point(468, 451)
        Me.lbl27.Name = "lbl27"
        Me.lbl27.Size = New System.Drawing.Size(30, 24)
        Me.lbl27.TabIndex = 78
        Me.lbl27.Text = "27"
        '
        'lbl32
        '
        Me.lbl32.AutoSize = True
        Me.lbl32.BackColor = System.Drawing.Color.Transparent
        Me.lbl32.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl32.ForeColor = System.Drawing.Color.White
        Me.lbl32.Location = New System.Drawing.Point(559, 517)
        Me.lbl32.Name = "lbl32"
        Me.lbl32.Size = New System.Drawing.Size(30, 24)
        Me.lbl32.TabIndex = 83
        Me.lbl32.Text = "32"
        '
        'lbl31
        '
        Me.lbl31.AutoSize = True
        Me.lbl31.BackColor = System.Drawing.Color.Transparent
        Me.lbl31.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl31.ForeColor = System.Drawing.Color.White
        Me.lbl31.Location = New System.Drawing.Point(468, 517)
        Me.lbl31.Name = "lbl31"
        Me.lbl31.Size = New System.Drawing.Size(30, 24)
        Me.lbl31.TabIndex = 82
        Me.lbl31.Text = "31"
        '
        'lbl29
        '
        Me.lbl29.AutoSize = True
        Me.lbl29.BackColor = System.Drawing.Color.Transparent
        Me.lbl29.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl29.ForeColor = System.Drawing.Color.White
        Me.lbl29.Location = New System.Drawing.Point(178, 517)
        Me.lbl29.Name = "lbl29"
        Me.lbl29.Size = New System.Drawing.Size(30, 24)
        Me.lbl29.TabIndex = 80
        Me.lbl29.Text = "29"
        '
        'lbl36
        '
        Me.lbl36.AutoSize = True
        Me.lbl36.BackColor = System.Drawing.Color.Transparent
        Me.lbl36.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl36.ForeColor = System.Drawing.Color.White
        Me.lbl36.Location = New System.Drawing.Point(559, 583)
        Me.lbl36.Name = "lbl36"
        Me.lbl36.Size = New System.Drawing.Size(30, 24)
        Me.lbl36.TabIndex = 87
        Me.lbl36.Text = "36"
        '
        'lbl35
        '
        Me.lbl35.AutoSize = True
        Me.lbl35.BackColor = System.Drawing.Color.Transparent
        Me.lbl35.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl35.ForeColor = System.Drawing.Color.White
        Me.lbl35.Location = New System.Drawing.Point(468, 583)
        Me.lbl35.Name = "lbl35"
        Me.lbl35.Size = New System.Drawing.Size(30, 24)
        Me.lbl35.TabIndex = 86
        Me.lbl35.Text = "35"
        '
        'lbl33
        '
        Me.lbl33.AutoSize = True
        Me.lbl33.BackColor = System.Drawing.Color.Transparent
        Me.lbl33.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl33.ForeColor = System.Drawing.Color.White
        Me.lbl33.Location = New System.Drawing.Point(178, 583)
        Me.lbl33.Name = "lbl33"
        Me.lbl33.Size = New System.Drawing.Size(30, 24)
        Me.lbl33.TabIndex = 84
        Me.lbl33.Text = "33"
        '
        'lbl40
        '
        Me.lbl40.AutoSize = True
        Me.lbl40.BackColor = System.Drawing.Color.Transparent
        Me.lbl40.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl40.ForeColor = System.Drawing.Color.White
        Me.lbl40.Location = New System.Drawing.Point(558, 649)
        Me.lbl40.Name = "lbl40"
        Me.lbl40.Size = New System.Drawing.Size(30, 24)
        Me.lbl40.TabIndex = 91
        Me.lbl40.Text = "40"
        '
        'lbl39
        '
        Me.lbl39.AutoSize = True
        Me.lbl39.BackColor = System.Drawing.Color.Transparent
        Me.lbl39.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl39.ForeColor = System.Drawing.Color.White
        Me.lbl39.Location = New System.Drawing.Point(467, 649)
        Me.lbl39.Name = "lbl39"
        Me.lbl39.Size = New System.Drawing.Size(30, 24)
        Me.lbl39.TabIndex = 90
        Me.lbl39.Text = "39"
        '
        'lbl37
        '
        Me.lbl37.AutoSize = True
        Me.lbl37.BackColor = System.Drawing.Color.Transparent
        Me.lbl37.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl37.ForeColor = System.Drawing.Color.White
        Me.lbl37.Location = New System.Drawing.Point(177, 649)
        Me.lbl37.Name = "lbl37"
        Me.lbl37.Size = New System.Drawing.Size(30, 24)
        Me.lbl37.TabIndex = 88
        Me.lbl37.Text = "37"
        '
        'lbl45
        '
        Me.lbl45.AutoSize = True
        Me.lbl45.BackColor = System.Drawing.Color.Transparent
        Me.lbl45.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl45.ForeColor = System.Drawing.Color.White
        Me.lbl45.Location = New System.Drawing.Point(558, 717)
        Me.lbl45.Name = "lbl45"
        Me.lbl45.Size = New System.Drawing.Size(30, 24)
        Me.lbl45.TabIndex = 100
        Me.lbl45.Text = "45"
        '
        'lbl44
        '
        Me.lbl44.AutoSize = True
        Me.lbl44.BackColor = System.Drawing.Color.Transparent
        Me.lbl44.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl44.ForeColor = System.Drawing.Color.White
        Me.lbl44.Location = New System.Drawing.Point(467, 717)
        Me.lbl44.Name = "lbl44"
        Me.lbl44.Size = New System.Drawing.Size(30, 24)
        Me.lbl44.TabIndex = 99
        Me.lbl44.Text = "44"
        '
        'lbl41
        '
        Me.lbl41.AutoSize = True
        Me.lbl41.BackColor = System.Drawing.Color.Transparent
        Me.lbl41.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl41.ForeColor = System.Drawing.Color.White
        Me.lbl41.Location = New System.Drawing.Point(177, 717)
        Me.lbl41.Name = "lbl41"
        Me.lbl41.Size = New System.Drawing.Size(30, 24)
        Me.lbl41.TabIndex = 97
        Me.lbl41.Text = "41"
        '
        'Seat45
        '
        Me.Seat45.Image = CType(resources.GetObject("Seat45.Image"), System.Drawing.Image)
        Me.Seat45.Location = New System.Drawing.Point(503, 688)
        Me.Seat45.Name = "Seat45"
        Me.Seat45.Size = New System.Drawing.Size(49, 50)
        Me.Seat45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat45.TabIndex = 96
        Me.Seat45.TabStop = False
        '
        'Seat44
        '
        Me.Seat44.Image = CType(resources.GetObject("Seat44.Image"), System.Drawing.Image)
        Me.Seat44.Location = New System.Drawing.Point(414, 688)
        Me.Seat44.Name = "Seat44"
        Me.Seat44.Size = New System.Drawing.Size(49, 50)
        Me.Seat44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat44.TabIndex = 95
        Me.Seat44.TabStop = False
        '
        'Seat43
        '
        Me.Seat43.Image = CType(resources.GetObject("Seat43.Image"), System.Drawing.Image)
        Me.Seat43.Location = New System.Drawing.Point(359, 688)
        Me.Seat43.Name = "Seat43"
        Me.Seat43.Size = New System.Drawing.Size(49, 50)
        Me.Seat43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat43.TabIndex = 94
        Me.Seat43.TabStop = False
        '
        'Seat42
        '
        Me.Seat42.Image = CType(resources.GetObject("Seat42.Image"), System.Drawing.Image)
        Me.Seat42.Location = New System.Drawing.Point(304, 688)
        Me.Seat42.Name = "Seat42"
        Me.Seat42.Size = New System.Drawing.Size(49, 50)
        Me.Seat42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat42.TabIndex = 93
        Me.Seat42.TabStop = False
        '
        'Seat41
        '
        Me.Seat41.Image = CType(resources.GetObject("Seat41.Image"), System.Drawing.Image)
        Me.Seat41.Location = New System.Drawing.Point(214, 688)
        Me.Seat41.Name = "Seat41"
        Me.Seat41.Size = New System.Drawing.Size(49, 50)
        Me.Seat41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Seat41.TabIndex = 92
        Me.Seat41.TabStop = False
        '
        'lbl43
        '
        Me.lbl43.AutoSize = True
        Me.lbl43.BackColor = System.Drawing.Color.Transparent
        Me.lbl43.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl43.Location = New System.Drawing.Point(368, 649)
        Me.lbl43.Name = "lbl43"
        Me.lbl43.Size = New System.Drawing.Size(30, 24)
        Me.lbl43.TabIndex = 101
        Me.lbl43.Text = "43"
        '
        'lblAvailable
        '
        Me.lblAvailable.AutoSize = True
        Me.lblAvailable.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvailable.Location = New System.Drawing.Point(45, 290)
        Me.lblAvailable.Name = "lblAvailable"
        Me.lblAvailable.Size = New System.Drawing.Size(87, 24)
        Me.lblAvailable.TabIndex = 102
        Me.lblAvailable.Text = "Available:"
        '
        'lblOccupied
        '
        Me.lblOccupied.AutoSize = True
        Me.lblOccupied.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOccupied.Location = New System.Drawing.Point(45, 392)
        Me.lblOccupied.Name = "lblOccupied"
        Me.lblOccupied.Size = New System.Drawing.Size(89, 24)
        Me.lblOccupied.TabIndex = 103
        Me.lblOccupied.Text = "Occupied:"
        '
        'picboxAvailable
        '
        Me.picboxAvailable.Image = CType(resources.GetObject("picboxAvailable.Image"), System.Drawing.Image)
        Me.picboxAvailable.Location = New System.Drawing.Point(64, 319)
        Me.picboxAvailable.Name = "picboxAvailable"
        Me.picboxAvailable.Size = New System.Drawing.Size(48, 50)
        Me.picboxAvailable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picboxAvailable.TabIndex = 104
        Me.picboxAvailable.TabStop = False
        '
        'picboxOccupied
        '
        Me.picboxOccupied.Image = CType(resources.GetObject("picboxOccupied.Image"), System.Drawing.Image)
        Me.picboxOccupied.Location = New System.Drawing.Point(64, 423)
        Me.picboxOccupied.Name = "picboxOccupied"
        Me.picboxOccupied.Size = New System.Drawing.Size(48, 50)
        Me.picboxOccupied.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picboxOccupied.TabIndex = 105
        Me.picboxOccupied.TabStop = False
        '
        'lblChooseDestination
        '
        Me.lblChooseDestination.AutoSize = True
        Me.lblChooseDestination.Font = New System.Drawing.Font("Roboto Cn", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChooseDestination.Location = New System.Drawing.Point(771, 215)
        Me.lblChooseDestination.Name = "lblChooseDestination"
        Me.lblChooseDestination.Size = New System.Drawing.Size(160, 23)
        Me.lblChooseDestination.TabIndex = 106
        Me.lblChooseDestination.Text = "Choose Destination:"
        '
        'comboxTerminalDeparture
        '
        Me.comboxTerminalDeparture.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboxTerminalDeparture.FormattingEnabled = True
        Me.comboxTerminalDeparture.Location = New System.Drawing.Point(828, 259)
        Me.comboxTerminalDeparture.Name = "comboxTerminalDeparture"
        Me.comboxTerminalDeparture.Size = New System.Drawing.Size(211, 28)
        Me.comboxTerminalDeparture.TabIndex = 107
        '
        'comboxTerminalDestination
        '
        Me.comboxTerminalDestination.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboxTerminalDestination.FormattingEnabled = True
        Me.comboxTerminalDestination.Location = New System.Drawing.Point(839, 304)
        Me.comboxTerminalDestination.Name = "comboxTerminalDestination"
        Me.comboxTerminalDestination.Size = New System.Drawing.Size(200, 28)
        Me.comboxTerminalDestination.TabIndex = 110
        '
        'datepickerDeparture
        '
        Me.datepickerDeparture.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datepickerDeparture.Location = New System.Drawing.Point(716, 358)
        Me.datepickerDeparture.Name = "datepickerDeparture"
        Me.datepickerDeparture.Size = New System.Drawing.Size(323, 28)
        Me.datepickerDeparture.TabIndex = 111
        Me.datepickerDeparture.Value = New Date(2025, 9, 13, 0, 0, 0, 0)
        '
        'pickPassenger
        '
        Me.pickPassenger.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pickPassenger.Location = New System.Drawing.Point(756, 446)
        Me.pickPassenger.Name = "pickPassenger"
        Me.pickPassenger.Size = New System.Drawing.Size(283, 28)
        Me.pickPassenger.TabIndex = 113
        '
        'lblPassenger
        '
        Me.lblPassenger.AutoSize = True
        Me.lblPassenger.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassenger.Location = New System.Drawing.Point(647, 446)
        Me.lblPassenger.Name = "lblPassenger"
        Me.lblPassenger.Size = New System.Drawing.Size(97, 24)
        Me.lblPassenger.TabIndex = 114
        Me.lblPassenger.Text = "Passenger:"
        '
        'comboxBusClassType
        '
        Me.comboxBusClassType.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboxBusClassType.FormattingEnabled = True
        Me.comboxBusClassType.Items.AddRange(New Object() {"Ordinary Class", "Regular Aircon Class", "Deluxe Class", "First Class", "Sleeper Bus"})
        Me.comboxBusClassType.Location = New System.Drawing.Point(813, 490)
        Me.comboxBusClassType.Name = "comboxBusClassType"
        Me.comboxBusClassType.Size = New System.Drawing.Size(226, 28)
        Me.comboxBusClassType.TabIndex = 115
        '
        'lblBusClassType
        '
        Me.lblBusClassType.AutoSize = True
        Me.lblBusClassType.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBusClassType.Location = New System.Drawing.Point(647, 495)
        Me.lblBusClassType.Name = "lblBusClassType"
        Me.lblBusClassType.Size = New System.Drawing.Size(134, 24)
        Me.lblBusClassType.TabIndex = 116
        Me.lblBusClassType.Text = "Bus Class Type:"
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.Transparent
        Me.btnCancel.FlatAppearance.BorderSize = 0
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnCancel.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Black
        Me.btnCancel.Location = New System.Drawing.Point(855, 556)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(147, 36)
        Me.btnCancel.TabIndex = 119
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'comboxTimeDeparture
        '
        Me.comboxTimeDeparture.Font = New System.Drawing.Font("Roboto Cn", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboxTimeDeparture.FormattingEnabled = True
        Me.comboxTimeDeparture.Items.AddRange(New Object() {"12:00 AM", "1:00 AM", "2:00 AM", "3:00 AM", "4:00 AM", "5:00 AM", "6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM", "10:00 PM", "11:00 PM"})
        Me.comboxTimeDeparture.Location = New System.Drawing.Point(716, 402)
        Me.comboxTimeDeparture.Name = "comboxTimeDeparture"
        Me.comboxTimeDeparture.Size = New System.Drawing.Size(323, 28)
        Me.comboxTimeDeparture.TabIndex = 120
        '
        'lblTerminalDeparture
        '
        Me.lblTerminalDeparture.AutoSize = True
        Me.lblTerminalDeparture.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTerminalDeparture.Location = New System.Drawing.Point(647, 263)
        Me.lblTerminalDeparture.Name = "lblTerminalDeparture"
        Me.lblTerminalDeparture.Size = New System.Drawing.Size(165, 24)
        Me.lblTerminalDeparture.TabIndex = 121
        Me.lblTerminalDeparture.Text = "Departure Terminal:"
        '
        'lblDateDeparture
        '
        Me.lblDateDeparture.AutoSize = True
        Me.lblDateDeparture.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateDeparture.Location = New System.Drawing.Point(651, 362)
        Me.lblDateDeparture.Name = "lblDateDeparture"
        Me.lblDateDeparture.Size = New System.Drawing.Size(51, 24)
        Me.lblDateDeparture.TabIndex = 122
        Me.lblDateDeparture.Text = "Date:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(651, 405)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 24)
        Me.Label6.TabIndex = 123
        Me.Label6.Text = "Time:"
        '
        'lblTerminalDestination
        '
        Me.lblTerminalDestination.AutoSize = True
        Me.lblTerminalDestination.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTerminalDestination.Location = New System.Drawing.Point(647, 304)
        Me.lblTerminalDestination.Name = "lblTerminalDestination"
        Me.lblTerminalDestination.Size = New System.Drawing.Size(179, 24)
        Me.lblTerminalDestination.TabIndex = 124
        Me.lblTerminalDestination.Text = "Destination Terminal:"
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.BorderRadius = 25
        Me.Guna2Elipse1.TargetControl = Me
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10.ForeColor = System.Drawing.Color.White
        Me.lbl10.Location = New System.Drawing.Point(268, 187)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(30, 24)
        Me.lbl10.TabIndex = 61
        Me.lbl10.Text = "10"
        '
        'lbl38
        '
        Me.lbl38.AutoSize = True
        Me.lbl38.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl38.ForeColor = System.Drawing.Color.White
        Me.lbl38.Location = New System.Drawing.Point(268, 649)
        Me.lbl38.Name = "lbl38"
        Me.lbl38.Size = New System.Drawing.Size(30, 24)
        Me.lbl38.TabIndex = 89
        Me.lbl38.Text = "38"
        '
        'lbl42
        '
        Me.lbl42.AutoSize = True
        Me.lbl42.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl42.ForeColor = System.Drawing.Color.White
        Me.lbl42.Location = New System.Drawing.Point(268, 717)
        Me.lbl42.Name = "lbl42"
        Me.lbl42.Size = New System.Drawing.Size(30, 24)
        Me.lbl42.TabIndex = 98
        Me.lbl42.Text = "42"
        '
        'lbl18
        '
        Me.lbl18.AutoSize = True
        Me.lbl18.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl18.ForeColor = System.Drawing.Color.White
        Me.lbl18.Location = New System.Drawing.Point(269, 319)
        Me.lbl18.Name = "lbl18"
        Me.lbl18.Size = New System.Drawing.Size(30, 24)
        Me.lbl18.TabIndex = 69
        Me.lbl18.Text = "18"
        '
        'lbl22
        '
        Me.lbl22.AutoSize = True
        Me.lbl22.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl22.ForeColor = System.Drawing.Color.White
        Me.lbl22.Location = New System.Drawing.Point(268, 385)
        Me.lbl22.Name = "lbl22"
        Me.lbl22.Size = New System.Drawing.Size(30, 24)
        Me.lbl22.TabIndex = 73
        Me.lbl22.Text = "22"
        '
        'lbl34
        '
        Me.lbl34.AutoSize = True
        Me.lbl34.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl34.ForeColor = System.Drawing.Color.White
        Me.lbl34.Location = New System.Drawing.Point(269, 583)
        Me.lbl34.Name = "lbl34"
        Me.lbl34.Size = New System.Drawing.Size(30, 24)
        Me.lbl34.TabIndex = 85
        Me.lbl34.Text = "34"
        '
        'lbl14
        '
        Me.lbl14.AutoSize = True
        Me.lbl14.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl14.ForeColor = System.Drawing.Color.White
        Me.lbl14.Location = New System.Drawing.Point(269, 253)
        Me.lbl14.Name = "lbl14"
        Me.lbl14.Size = New System.Drawing.Size(30, 24)
        Me.lbl14.TabIndex = 65
        Me.lbl14.Text = "14"
        '
        'lbl26
        '
        Me.lbl26.AutoSize = True
        Me.lbl26.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl26.ForeColor = System.Drawing.Color.White
        Me.lbl26.Location = New System.Drawing.Point(269, 451)
        Me.lbl26.Name = "lbl26"
        Me.lbl26.Size = New System.Drawing.Size(30, 24)
        Me.lbl26.TabIndex = 77
        Me.lbl26.Text = "26"
        '
        'lbl30
        '
        Me.lbl30.AutoSize = True
        Me.lbl30.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl30.ForeColor = System.Drawing.Color.White
        Me.lbl30.Location = New System.Drawing.Point(269, 517)
        Me.lbl30.Name = "lbl30"
        Me.lbl30.Size = New System.Drawing.Size(30, 24)
        Me.lbl30.TabIndex = 81
        Me.lbl30.Text = "30"
        '
        'lbl02
        '
        Me.lbl02.AutoSize = True
        Me.lbl02.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl02.ForeColor = System.Drawing.Color.White
        Me.lbl02.Location = New System.Drawing.Point(269, 54)
        Me.lbl02.Name = "lbl02"
        Me.lbl02.Size = New System.Drawing.Size(30, 24)
        Me.lbl02.TabIndex = 53
        Me.lbl02.Text = "02"
        '
        'lbl06
        '
        Me.lbl06.AutoSize = True
        Me.lbl06.Font = New System.Drawing.Font("Roboto Cn", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl06.ForeColor = System.Drawing.Color.White
        Me.lbl06.Location = New System.Drawing.Point(268, 121)
        Me.lbl06.Name = "lbl06"
        Me.lbl06.Size = New System.Drawing.Size(30, 24)
        Me.lbl06.TabIndex = 57
        Me.lbl06.Text = "06"
        '
        'PictureBox3
        '
        Me.PictureBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(1105, 774)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 129
        Me.PictureBox3.TabStop = False
        '
        'UserScheduleAndSeat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(201, Byte), Integer), CType(CType(2, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1105, 774)
        Me.Controls.Add(Me.lblTerminalDestination)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblDateDeparture)
        Me.Controls.Add(Me.lblTerminalDeparture)
        Me.Controls.Add(Me.comboxTimeDeparture)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lblBusClassType)
        Me.Controls.Add(Me.comboxBusClassType)
        Me.Controls.Add(Me.lblPassenger)
        Me.Controls.Add(Me.pickPassenger)
        Me.Controls.Add(Me.datepickerDeparture)
        Me.Controls.Add(Me.comboxTerminalDestination)
        Me.Controls.Add(Me.comboxTerminalDeparture)
        Me.Controls.Add(Me.lblChooseDestination)
        Me.Controls.Add(Me.picboxOccupied)
        Me.Controls.Add(Me.picboxAvailable)
        Me.Controls.Add(Me.lblOccupied)
        Me.Controls.Add(Me.lblAvailable)
        Me.Controls.Add(Me.lbl43)
        Me.Controls.Add(Me.lbl45)
        Me.Controls.Add(Me.lbl44)
        Me.Controls.Add(Me.lbl42)
        Me.Controls.Add(Me.lbl41)
        Me.Controls.Add(Me.Seat45)
        Me.Controls.Add(Me.Seat44)
        Me.Controls.Add(Me.Seat43)
        Me.Controls.Add(Me.Seat42)
        Me.Controls.Add(Me.Seat41)
        Me.Controls.Add(Me.lbl40)
        Me.Controls.Add(Me.lbl39)
        Me.Controls.Add(Me.lbl38)
        Me.Controls.Add(Me.lbl37)
        Me.Controls.Add(Me.lbl36)
        Me.Controls.Add(Me.lbl35)
        Me.Controls.Add(Me.lbl34)
        Me.Controls.Add(Me.lbl33)
        Me.Controls.Add(Me.lbl32)
        Me.Controls.Add(Me.lbl31)
        Me.Controls.Add(Me.lbl30)
        Me.Controls.Add(Me.lbl29)
        Me.Controls.Add(Me.lbl28)
        Me.Controls.Add(Me.lbl27)
        Me.Controls.Add(Me.lbl26)
        Me.Controls.Add(Me.lbl25)
        Me.Controls.Add(Me.lbl24)
        Me.Controls.Add(Me.lbl23)
        Me.Controls.Add(Me.lbl22)
        Me.Controls.Add(Me.lbl21)
        Me.Controls.Add(Me.lbl20)
        Me.Controls.Add(Me.lbl19)
        Me.Controls.Add(Me.lbl18)
        Me.Controls.Add(Me.lbl17)
        Me.Controls.Add(Me.lbl16)
        Me.Controls.Add(Me.lbl15)
        Me.Controls.Add(Me.lbl14)
        Me.Controls.Add(Me.lbl13)
        Me.Controls.Add(Me.lbl12)
        Me.Controls.Add(Me.lbl11)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.lbl09)
        Me.Controls.Add(Me.lbl08)
        Me.Controls.Add(Me.lbl07)
        Me.Controls.Add(Me.lbl06)
        Me.Controls.Add(Me.lbl05)
        Me.Controls.Add(Me.lbl04)
        Me.Controls.Add(Me.lbl03)
        Me.Controls.Add(Me.lbl02)
        Me.Controls.Add(Me.lbl01)
        Me.Controls.Add(Me.Seat40)
        Me.Controls.Add(Me.Seat36)
        Me.Controls.Add(Me.Seat32)
        Me.Controls.Add(Me.Seat28)
        Me.Controls.Add(Me.Seat24)
        Me.Controls.Add(Me.Seat20)
        Me.Controls.Add(Me.Seat16)
        Me.Controls.Add(Me.Seat12)
        Me.Controls.Add(Me.Seat08)
        Me.Controls.Add(Me.Seat04)
        Me.Controls.Add(Me.Seat39)
        Me.Controls.Add(Me.Seat35)
        Me.Controls.Add(Me.Seat31)
        Me.Controls.Add(Me.Seat27)
        Me.Controls.Add(Me.Seat23)
        Me.Controls.Add(Me.Seat19)
        Me.Controls.Add(Me.Seat15)
        Me.Controls.Add(Me.Seat11)
        Me.Controls.Add(Me.Seat07)
        Me.Controls.Add(Me.Seat03)
        Me.Controls.Add(Me.Seat38)
        Me.Controls.Add(Me.Seat34)
        Me.Controls.Add(Me.Seat30)
        Me.Controls.Add(Me.Seat26)
        Me.Controls.Add(Me.Seat22)
        Me.Controls.Add(Me.Seat18)
        Me.Controls.Add(Me.Seat14)
        Me.Controls.Add(Me.Seat10)
        Me.Controls.Add(Me.Seat06)
        Me.Controls.Add(Me.Seat02)
        Me.Controls.Add(Me.Seat37)
        Me.Controls.Add(Me.Seat33)
        Me.Controls.Add(Me.Seat29)
        Me.Controls.Add(Me.Seat25)
        Me.Controls.Add(Me.Seat21)
        Me.Controls.Add(Me.Seat17)
        Me.Controls.Add(Me.Seat13)
        Me.Controls.Add(Me.Seat09)
        Me.Controls.Add(Me.Seat05)
        Me.Controls.Add(Me.lblChooseSeat)
        Me.Controls.Add(Me.Seat01)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.PictureBox3)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "UserScheduleAndSeat"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "s"
        CType(Me.Seat01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat05, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat09, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat06, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat08, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat04, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat07, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat03, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seat41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picboxAvailable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picboxOccupied, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pickPassenger, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents Seat01 As System.Windows.Forms.PictureBox
    Friend WithEvents lblChooseSeat As System.Windows.Forms.Label
    Friend WithEvents Seat05 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat09 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat13 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat17 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat21 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat25 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat29 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat33 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat37 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat38 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat34 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat30 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat26 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat22 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat18 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat14 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat10 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat06 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat02 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat40 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat36 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat32 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat28 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat24 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat20 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat16 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat12 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat08 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat04 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat39 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat35 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat31 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat27 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat23 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat19 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat15 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat11 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat07 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat03 As System.Windows.Forms.PictureBox
    Friend WithEvents lbl01 As System.Windows.Forms.Label
    Friend WithEvents lbl03 As System.Windows.Forms.Label
    Friend WithEvents lbl04 As System.Windows.Forms.Label
    Friend WithEvents lbl05 As System.Windows.Forms.Label
    Friend WithEvents lbl07 As System.Windows.Forms.Label
    Friend WithEvents lbl08 As System.Windows.Forms.Label
    Friend WithEvents lbl09 As System.Windows.Forms.Label
    Friend WithEvents lbl20 As System.Windows.Forms.Label
    Friend WithEvents lbl19 As System.Windows.Forms.Label
    Friend WithEvents lbl17 As System.Windows.Forms.Label
    Friend WithEvents lbl16 As System.Windows.Forms.Label
    Friend WithEvents lbl15 As System.Windows.Forms.Label
    Friend WithEvents lbl13 As System.Windows.Forms.Label
    Friend WithEvents lbl12 As System.Windows.Forms.Label
    Friend WithEvents lbl11 As System.Windows.Forms.Label
    Friend WithEvents lbl25 As System.Windows.Forms.Label
    Friend WithEvents lbl24 As System.Windows.Forms.Label
    Friend WithEvents lbl23 As System.Windows.Forms.Label
    Friend WithEvents lbl21 As System.Windows.Forms.Label
    Friend WithEvents lbl28 As System.Windows.Forms.Label
    Friend WithEvents lbl27 As System.Windows.Forms.Label
    Friend WithEvents lbl32 As System.Windows.Forms.Label
    Friend WithEvents lbl31 As System.Windows.Forms.Label
    Friend WithEvents lbl29 As System.Windows.Forms.Label
    Friend WithEvents lbl36 As System.Windows.Forms.Label
    Friend WithEvents lbl35 As System.Windows.Forms.Label
    Friend WithEvents lbl33 As System.Windows.Forms.Label
    Friend WithEvents lbl40 As System.Windows.Forms.Label
    Friend WithEvents lbl39 As System.Windows.Forms.Label
    Friend WithEvents lbl37 As System.Windows.Forms.Label
    Friend WithEvents lbl45 As System.Windows.Forms.Label
    Friend WithEvents lbl44 As System.Windows.Forms.Label
    Friend WithEvents lbl41 As System.Windows.Forms.Label
    Friend WithEvents Seat45 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat44 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat43 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat42 As System.Windows.Forms.PictureBox
    Friend WithEvents Seat41 As System.Windows.Forms.PictureBox
    Friend WithEvents lbl43 As System.Windows.Forms.Label
    Friend WithEvents lblAvailable As System.Windows.Forms.Label
    Friend WithEvents lblOccupied As System.Windows.Forms.Label
    Friend WithEvents picboxAvailable As System.Windows.Forms.PictureBox
    Friend WithEvents picboxOccupied As System.Windows.Forms.PictureBox
    Friend WithEvents lblChooseDestination As System.Windows.Forms.Label
    Friend WithEvents comboxTerminalDeparture As System.Windows.Forms.ComboBox
    Friend WithEvents comboxTerminalDestination As System.Windows.Forms.ComboBox
    Friend WithEvents datepickerDeparture As System.Windows.Forms.DateTimePicker
    Friend WithEvents pickPassenger As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPassenger As System.Windows.Forms.Label
    Friend WithEvents comboxBusClassType As System.Windows.Forms.ComboBox
    Friend WithEvents lblBusClassType As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents comboxTimeDeparture As System.Windows.Forms.ComboBox
    Friend WithEvents lblTerminalDeparture As System.Windows.Forms.Label
    Friend WithEvents lblDateDeparture As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblTerminalDestination As System.Windows.Forms.Label
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents lbl42 As System.Windows.Forms.Label
    Friend WithEvents lbl38 As System.Windows.Forms.Label
    Friend WithEvents lbl34 As System.Windows.Forms.Label
    Friend WithEvents lbl30 As System.Windows.Forms.Label
    Friend WithEvents lbl26 As System.Windows.Forms.Label
    Friend WithEvents lbl22 As System.Windows.Forms.Label
    Friend WithEvents lbl18 As System.Windows.Forms.Label
    Friend WithEvents lbl14 As System.Windows.Forms.Label
    Friend WithEvents lbl10 As System.Windows.Forms.Label
    Friend WithEvents lbl06 As System.Windows.Forms.Label
    Friend WithEvents lbl02 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
End Class
